// #include "Enemy1.hpp"

// void Enemy::attackKnight(Knight& knight) {
//     int random = rand() % 10;
    
//     if (random >= 0 && random <= 3){
//         knight.decreaseHealth(16); //Fireball
//         // need to implement animation
//     }
//     else if (random > 3 && random <= 6){
//         knight.decreaseHealth(32); //Lightning Strike
//         //need to implement animation
//     }
//     else if (random > 6){
//         health += 14;
//     }
    
// }